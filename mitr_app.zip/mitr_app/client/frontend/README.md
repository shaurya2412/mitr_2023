This is the frontend for our Mitr Application. It is a React application that uses the Mitr API to provide a user interface for the Mitr application.

## Getting Started

npm start

### Prerequisites

What things you need to install the software and how to install them

```
Should have node installed
```
