export const subreddits = [
  {
    id: 1,
    name: 'memes',
    description: 'dankest memes in town!! yeehaw!',
    created_at: '2021-04-22T02:08:23.465Z',
  },
  {
    id: 2,
    name: 'pics',
    description: 'a place to share your photos',
    created_at: '2021-04-22T02:08:23.467Z',
  },
  {
    id: 3,
    name: 'news',
    description: 'keep up to date!',
    created_at: '2021-04-22T02:08:23.469Z',
  },
  {
    id: 4,
    name: 'react',
    description: 'the best frontend framework',
    created_at: '2021-05-04T03:03:18.232Z',
  },
  {
    id: 5,
    name: 'dota2',
    description: 'Defense of the Ancients 2 - Electric Boogaloo',
    created_at: '2021-05-04T03:16:44.186Z',
  },
  {
    id: 6,
    name: 'anime',
    description: 'Japanimations',
    created_at: '2021-05-04T03:18:47.872Z',
  },
  {
    id: 9,
    name: 'manga',
    description: '',
    created_at: '2021-05-04T03:36:06.753Z',
  },
];
