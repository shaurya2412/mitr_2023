export const user = {
  id: 1,
  username: 'bill',
  created_at: '2021-04-22T02:08:23.580Z',
  updated_at: '2021-05-06T15:46:49.081Z',
};

export const token =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNjIwMzE2MDA5fQ.HMkCul_qYNuxDsLcGqGrCzWfRHQ77HDliRqeBTRnD1I';
