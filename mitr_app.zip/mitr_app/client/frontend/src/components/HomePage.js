import PostList from './PostList';

const HomePage = () => <PostList />;

export default HomePage;
